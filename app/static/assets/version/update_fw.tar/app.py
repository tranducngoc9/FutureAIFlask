#!venv/bin/python
import os
from flask import Flask, url_for, redirect, render_template, request, abort, json, Response, request, render_template
from flask_sqlalchemy import SQLAlchemy
from flask_security import Security, SQLAlchemyUserDatastore, \
    UserMixin, RoleMixin, login_required, current_user
from flask_security.utils import encrypt_password
import flask_admin
from flask_admin.contrib import sqla
from flask_admin import helpers as admin_helpers
from flask_admin import BaseView, expose, AdminIndexView
from flask_admin.form import SecureForm
from flask_admin.actions import action
from os import path, getcwd
from werkzeug.utils import secure_filename
from sqlalchemy.sql import text
from flask_admin import form
from datetime import date, timedelta, datetime
from flask import flash
from PIL import Image
from wtforms import HiddenField, IntegerField, Form, BooleanField, StringField, validators
from wtforms.validators import InputRequired
from flask_admin.helpers import get_redirect_target
from wtforms.ext.sqlalchemy.fields import QuerySelectField
from sqlalchemy import func
from jinja2 import Markup
import time
import shutil
import base64
import sqlite3
import subprocess
import socket
import numpy as np
import cv2
from flask_socketio import SocketIO, emit
import json as js
from flask_admin.contrib.sqla.filters import BaseSQLAFilter, BooleanEqualFilter
from sqlalchemy.ext.hybrid import hybrid_property
import time
import atexit
from apscheduler.schedulers.background import BackgroundScheduler
from flask_babelex import Babel, gettext, lazy_gettext
from wifi import Cell, Scheme
import bluetooth
from google.cloud import texttospeech
import sys
import multiprocessing
os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = '/home/mq/Desktop/face_nano/TTS-Demo-a1c484535a80.json'
# Create Flask application
app = Flask(__name__)
app.config.from_pyfile('config.py')
db = SQLAlchemy(app)

socketio = SocketIO(app)
app.config['file_allowed'] = ['image/png', 'image/jpeg', 'application/octet-stream']
app.config['json_config_file'] = '/home/mq/crm/crm_config.txt'

basedir = os.path.abspath(os.path.dirname(__file__))
file_path = os.path.join(basedir, 'static/img')
face_path = path.join(basedir, 'faces')
feature_db_path = os.path.join(basedir, 'static/db/feature.db')
global_volume = 0
speaker_control = 2


def strAndhex2RealStr(strbegin):
    result = b""
    result = bytearray(result)
    i = 4
    while i < len(strbegin): 
        if(strbegin[i] == "\\"):
            result.append(int(strbegin[i+2:i+4], 16))
            i += 4
        else:
            result.append(ord(strbegin[i]))
            i += 1
    b = result.decode('utf8')
    return b
def getWifiList():
    Cell.all('wlan0')
    cell = Cell.all('wlan0')

    # convert map to set
    setSSID = set(cell)
    result = ""
    for x in setSSID:
        x = str(x)
#        temp = x[len('Cell(ssid='):len(x)-1]
        result += strAndhex2RealStr(x) + " "
    return result

def Speaker_config():
    print ("[HIEU_LOG]: ====== Speaker_config")
    subprocess.call("pulseaudio --k", shell=True)
    ret = subprocess.call("bash /home/mq/Desktop/face_nano/audio_start.sh",shell=True)
    print ("[HIEU_LOG]: ====== Speaker_config, ret = ",ret)
    subprocess.call("pacmd set-sink-volume alsa_output.usb-GeneralPlus_USB_Audio_Device-00.analog-stereo 98303",shell=True)
    return

def success_handle(output, status=200, mimetype='application/json'):
    return Response(output, status=status, mimetype=mimetype)


def error_handle(error_message, status=500, mimetype='application/json'):
    return Response(json.dumps({"error": {"message": error_message}}), status=status, mimetype=mimetype)


# Define models
roles_users = db.Table(
    'roles_users',
    db.Column('user_id', db.Integer(), db.ForeignKey('user.id')),
    db.Column('role_id', db.Integer(), db.ForeignKey('role.id'))
)


class Role(db.Model, RoleMixin):
    id = db.Column(db.Integer(), primary_key=True)
    name = db.Column(db.String(80), unique=True)
    description = db.Column(db.String(255))

    def __str__(self):
        return self.name


class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    first_name = db.Column(db.String(255))
    last_name = db.Column(db.String(255))
    email = db.Column(db.String(255))
    password = db.Column(db.String(255))
    active = db.Column(db.Boolean())
    is_unknown = db.Column(db.Boolean(), default=False)
    confirmed_at = db.Column(db.DateTime())
    roles = db.relationship('Role', secondary=roles_users,
                            backref=db.backref('users', lazy='dynamic'))

    def __str__(self):
        if (self.last_name != None):
            return "{0} {1}".format(self.first_name,self.last_name)
        else:
            return self.first_name


# Setup Flask-Security
user_datastore = SQLAlchemyUserDatastore(db, User, Role)
security = Security(app, user_datastore)


# Create customized model view class
class MyModelView(sqla.ModelView):


    def is_accessible(self):
        if not current_user.is_active or not current_user.is_authenticated:
            return False

        if current_user.has_role('superuser'):
            return True

        return False

    def _handle_view(self, name, **kwargs):
        """
        Override builtin _handle_view in order to redirect users when a view is not accessible.
        """
        if not self.is_accessible():
            if current_user.is_authenticated:
                # permission denied
                abort(403)
            else:
                # login
                return redirect(url_for('security.login', next=request.url))


    # can_edit = True
    edit_modal = True
    create_modal = True    
    can_export = True
    can_view_details = True
    details_modal = True

class MyHomeView(AdminIndexView):
    @expose('/')
    def index(self):
        return self.render('admin/index.html')

@app.template_filter('total_time')
def total_time(entry):
    """
    textual representation of total work time
    """
    total_min = entry.total_min
    if total_min:
        return "%d:%02d" % (total_min // 60, total_min % 60)


@app.template_filter('hhmm')
def hhmm(time):
    """
    textual representation of time in format HH:MM
    """
    return time if time else ''


class SettingView(BaseView):
    @expose('/')
    def index(self):
        #myCmd = 'iwlist wlan0 scan | grep "ESSID:" | cut -d ":" -f 2'
        #result = subprocess.check_output(myCmd, shell=True)
        #print("cmd result:", result)
        #result = b'"MQSOLUTIONS.VN"\n"Mr.Kutj"\n"MQSOLUTIONS.VN"\n"PPEDGE"\n"GemtekPico"\n"MQSOLUTIONS.VN"\n"HBG"\n"HUAWEI-7x27"\n"TP-LINK_8F52DC"\n"Large MeetingRroom"\n"HBG-NO SHARE PASS"\n';
        if (os.path.isfile(app.config['json_config_file'])):
            with open(app.config['json_config_file']) as json_file:  
                data = json.load(json_file)
                self._template_args['server_url'] = data['server_url'] if 'server_url' in data else ""
                self._template_args['camera_pos_x'] = data['camera_x'] if 'camera_x' in data else ""
                self._template_args['camera_pos_y'] = data['camera_y'] if 'camera_y' in data else ""
                self._template_args['camera_pos_width'] = data['camera_width'] if 'camera_width' in data else ""
                self._template_args['camera_pos_height'] = data['camera_height'] if 'camera_height' in data else ""
                self._template_args['version'] = data['version'] if 'version' in data else "0.0.1"
                
        return self.render('admin/setting.html')

class Streaming(BaseView):
    @expose('/')
    def index(self):
        gw = os.popen("ip -4 route show default").read().split()
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        ipaddr = "192.168.2.1"
        if (len(gw) > 2):
            s.connect((gw[2], 0))
            ipaddr = s.getsockname()[0]
        
        self._template_args['streaming_url'] = "http://"+ipaddr+":7777/?action=stream"
        self._template_args['streaming_url1'] = "http://"+ipaddr+":8888/?action=stream"
        return self.render('admin/streaming.html')


# Flask views
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api', methods=['GET'])
def homepage():
    output = json.dumps({"api": '1.0'})
    return success_handle(output)

@app.route('/api/playName', methods=['POST'])
def playName():
    output = json.dumps({"success": True})
    if (speaker_control == 0):
        return success_handle(output)
    elif(speaker_control == 1): 
        pulse_check_cmd =  "pgrep -x 'pulseaudio'"
        ret_pulse = subprocess.call(pulse_check_cmd, shell=True)
        if (ret_pulse == 0):
            print ("[HIEU_LOG]: pulseaudio started")
        else:
            print ("[HIEU_LOG]: pulseaudio didn't start")
            print ("[HIEU_LOG]: ====== Restart pulseaudio")
            ret = subprocess.call("bash /home/mq/Desktop/face_nano/audio_start.sh",shell=True)
            if (global_volume > 0):
                cmd = "pacmd set-sink-volume alsa_output.usb-GeneralPlus_USB_Audio_Device-00.analog-stereo " + str(global_volume)
                print("[HIEU LOG] audio restart =============> cmd = ", cmd)
                subprocess.call(cmd, shell=True)
            else:
                print("[HIEU LOG] audio restart 111 ")
                subprocess.call("pacmd set-sink-volume alsa_output.usb-GeneralPlus_USB_Audio_Device-00.analog-stereo 98303", shell=True)
            print ("[HIEU_LOG]: audio restart=========> ret = ", ret)
        
        full_name = request.form['full_name']
        proc_mp3 = multiprocessing.Process(target=playMp3, args=(full_name,))
        proc_mp3.start()
        return success_handle(output)

def playMp3(full_name):
    # get name in form data
    print ("[HIEU_LOG]: =======================> ", full_name)
    if (full_name.find("k_") != -1):
        print("+++++cannot find")
        full_name= 'quý khách'

    input_text = 'Xin chào ' + full_name
    print(input_text)

    # Instantiates a client
    client = texttospeech.TextToSpeechClient()
    
    # Set the text input to be synthesized
    synthesis_input = texttospeech.types.SynthesisInput(text=input_text)
    
    # Build the voice request, select the language code ("en-US") and the ssml
    # voice gender ("neutral")
    voice = texttospeech.types.VoiceSelectionParams(
        language_code='vi',
        ssml_gender=texttospeech.enums.SsmlVoiceGender.NEUTRAL)
    
    # Select the type of audio file you want returned
    audio_config = texttospeech.types.AudioConfig(
        audio_encoding=texttospeech.enums.AudioEncoding.MP3,speaking_rate=1.2)
    
    # Perform the text-to-speech request on the text input with the selected
    # voice parameters and audio file type
    response = client.synthesize_speech(synthesis_input, voice, audio_config)
    
    # The response's audio_content is binary.
    
    with open('output.mp3', 'wb') as out:
        # Write the response to the output file.
        out.write(response.audio_content)
        print('Audio content written to file "output.mp3"')
    cmd = "ffplay -autoexit output.mp3 -nodisp"
    subprocess.call(cmd, shell=True)
    return

@app.route('/api/wifi_setting', methods=['POST'])
def wifi_setting():
    output = json.dumps({"success": True})
    
    # get name in form data
    ssid = request.form['setting_wifi_ssid']
    password = request.form['setting_wifi_password']

    myCmd = 'sudo sh /etc/ConfigNW.sh -m wifi -s "'+ssid+'" -p "'+password+'" -e 5'
    os.system(myCmd)

    return success_handle(output)

@app.route('/api/wifi_scaning', methods=['POST'])
def wifi_scaning():
    print ("[lhm log] =============> scan wifi, /api/wifi_scaning")
    wifiList = getWifiList()
    output = json.dumps({"success": True, "wifiList":wifiList})
    return success_handle(output)

@app.route('/api/volume_setting', methods=['POST'])
def volume_setting():
    global global_volume
    print ("[HIEU LOG] =============> Setup volume, /api/volume_setting")
    param = request.form['setting_volume']
    volume = int(param)
    print("[HIEU LOG] =============> volume = ", volume)
    speaker_volume = 196607*volume
    speaker_volume = int(speaker_volume//100)
    global_volume = int(speaker_volume)
    cmd = "pacmd set-sink-volume alsa_output.usb-GeneralPlus_USB_Audio_Device-00.analog-stereo " + str(speaker_volume)
    print("[HIEU LOG] =============> cmd = ", cmd)
    subprocess.call(cmd, shell=True)
    output = json.dumps({"success": True})
    return success_handle(output)

@app.route('/api/turn_speaker_on', methods=['POST'])
def turn_speaker_on():
    global speaker_control
    speaker_control = 1
    print ("[HIEU LOG] Turn speaker on =============> speaker_control = ",speaker_control)
    output = json.dumps({"success": True})
    return success_handle(output)

@app.route('/api/turn_speaker_off', methods=['POST'])
def turn_speaker_off():
    global speaker_control
    speaker_control = 0
    print ("[HIEU LOG] Turn speaker off =============> speaker_control = ",speaker_control)
    output = json.dumps({"success": True})
    return success_handle(output)

@app.route('/api/timing_seting', methods=['POST'])
def timing_setting():
    print("[lhm log] =============> scan bluetooth, /api/timing_seting")
    startOff = request.form['startOff']
    endOff = request.form['endOff']
    print("startOff", startOff, "endOff", endOff)

    temp = startOff.split(":")
    startOffHour = temp[0]
    startOffMinute = temp[1]

    temp = endOff.split(":")
    endOffHour = temp[0]
    endOffMinute = temp[1]

    cmdStr = "sudo sed -i '$ d' /var/spool/cron/crontabs/root"
    result = subprocess.check_output(cmdStr, shell=True)
    print("delete last line of file /var/spool/cron/crontabs/root", result)

    cmdStr = "echo '" + startOffMinute + " " + startOffHour + " * * * /etc/suspend_until " + endOffHour + ":" + endOffMinute + "' | sudo tee -a /var/spool/cron/crontabs/root"
    print(cmdStr)
    result = subprocess.check_output(cmdStr, shell=True)
    print("echo new data to file /var/spool/cron/crontabs/root", result)

    output = json.dumps({"success": True})
    return success_handle(output)

@app.route('/api/direct_network_setting', methods=['POST'])
def direct_setting():
    output = json.dumps({"success": True, "ip": "192.168.2.1"})

    # get name in form data
    ssid = request.form['setting_direct_ssid']
    password = request.form['setting_direct_password']

    #myCmd = 'sh /etc/ConfigNW.sh -m direct -s "'+ssid+'" -p "'+password+'"'
    myCmd = 'sh /etc/ConfigNW.sh -m direct -s "'+ssid+'" -p "'+password+'" -e 5'
    print(myCmd)
    os.system(myCmd)

    return success_handle(output)

@app.route('/api/camera_setting', methods=['POST'])
def camera_setting():
    output = json.dumps({"success": True})

    # get name in form data
    # x = request.form['x']
    # y = request.form['y']
    # width = request.form['width']
    # height = request.form['height']
    data = {}  
    data['admin_url'] = basedir
    data['server_url'] = request.form['setting_camera_server_url']
    data['camera_x'] = request.form['setting_camera_pos_x']
    data['camera_y'] = request.form['setting_camera_pos_y']
    data['camera_width'] = request.form['setting_camera_pos_width']
    data['camera_height'] = request.form['setting_camera_pos_height']
    # data['camera'] = []  
    # data['camera'].append({  
    #     'x': request.form['setting_camera_pos_x'],
    #     'y': request.form['setting_camera_pos_y'],
    #     'width': request.form['setting_camera_pos_width'],
    #     'height': request.form['setting_camera_pos_height']
    # })

    with open(app.config['json_config_file'], 'w') as outfile:  
        json.dump(data, outfile)
    
    myCmd = 'sh ' + basedir +'/../restart.sh'
    print(myCmd)
    os.system(myCmd)

    time.sleep(10) 

    return success_handle(output)

@app.route('/api/activate_setting', methods=['POST'])
def activate_setting():
    output = json.dumps({"success": True})

    # get name in form data
    key = request.form['setting_activate']

    #myCmd = 'sh /etc/ConfigNW.sh -m direct -s "'+ssid+'" -p "'+password+'"'
    myCmd = 'ans '+ key
    result = subprocess.check_output(myCmd, shell=True)
    print("cmd result:", result)
    if (result == b'1'):
        return success_handle(output)
    else:
        return error_handle("Cannot activate the device")

def build_sample_db():
    """
    Populate a small db with some example entries.
    """

    import string
    import random

    print("build_sample_db")

    db.drop_all()
    db.create_all()

    with app.app_context():
        user_role = Role(name='user')
        staff_role = Role(name='staff')
        super_user_role = Role(name='superuser')
        db.session.add(user_role)
        db.session.add(staff_role)
        db.session.add(super_user_role)
        db.session.commit()

        admin_user = user_datastore.create_user(
            first_name='Admin',
            email='admin',
            password=encrypt_password('MQ1234'),
            roles=[super_user_role]
        )

        staff_user = user_datastore.create_user(
            first_name='Staff',
            email='staff',
            password=encrypt_password('MQ1234'),
            roles=[staff_role]
        )

        db.session.commit()


    return

# Create admin
admin = flask_admin.Admin(
    app,
    'MQ AI CAMERA',
    base_template='my_master.html',
    template_mode='bootstrap3',
    index_view=MyHomeView()
)

app_dir = os.path.realpath(os.path.dirname(__file__))
database_path = os.path.join(app_dir, app.config['DATABASE_FILE'])
if not os.path.exists(database_path):
    build_sample_db()

# Add model views
admin.add_view(SettingView(name="Setting", endpoint='setting', menu_icon_type='fa', menu_icon_value='fa-cog',))
admin.add_view(Streaming(name="Streaming", endpoint='streaming', menu_icon_type='fa', menu_icon_value='fa-file-video-o',))



# define a context processor for merging flask-admin's template context into the
# flask-security views.
@security.context_processor
def security_context_processor():
    return dict(
        admin_base_template=admin.base_template,
        admin_view=admin.index_view,
        h=admin_helpers,
        get_url=url_for
    )

if __name__ == '__main__':
    Speaker_config()
    socketio.run(app, host='0.0.0.0', port=1234, debug=True)

    # Start app
    #app.run(debug=True)
    #app.run(host='0.0.0.0', port=1234, debug=False)
